// Signal Garden presentation — an ordered investor-ready narrative from garden problem to operating documents.
import { ArrowDown, ArrowRight, Bot, Check, CircleGauge, CloudRain, Droplets, ShieldAlert, ShieldCheck, Sprout, TriangleAlert, Waves, Zap } from "lucide-react";
import { BrandMark } from "@/components/BrandMark";
import { DocumentLibrary } from "@/components/DocumentLibrary";
import { PresentationRail } from "@/components/PresentationRail";
import { SectionHeader } from "@/components/SectionHeader";

const featureModules = [
  [CircleGauge, "Weather & microclimate", "Temperature, humidity, rainfall, UV/light, wind, historical readings, and heat or rain alerts."],
  [Sprout, "Plant & soil health", "Zone moisture, soil temperature, light exposure, dry-soil and overwatering detection, and trend history."],
  [Waves, "Vertical farming", "Independent levels, per-zone monitoring, uneven moisture and sunlight detection, plus expandable nodes."],
  [Droplets, "Smart irrigation", "Drip, micro-drip, misting, sprinkler, zone watering, local schedules, triggers, history, and emergency stop."],
  [Waves, "Water tank monitor", "Level, percentage, low and critical thresholds, overflow warning, remaining-water estimate, and consumption tracking."],
  [CloudRain, "Rainwater reuse", "Collection monitoring, rainwater-first logic, municipal fallback, routing valves, and utilization analytics."],
  [Bot, "Predictive watering", "Historical conditions, weather, plant type, season, water availability, eco mode, and explainable recommendations."],
  [Bot, "Pest & plant insight", "Periodic photography, advisory image analysis, plant-condition alerts, image history, and human confirmation."],
  [Droplets, "Fertilizer injector", "Optional peristaltic dosing, zone schedules, watering-linked application, logs, override, and safety lockout."],
  [CircleGauge, "Microclimate control", "Optional fans, shade mechanisms, temperature and light triggers, schedules, and extreme-heat protection."],
  [Sprout, "Growth time-lapse", "Scheduled photography, visual growth records, image history, plant comparisons, and export-ready video."],
  [Check, "Garden assistant", "Dashboard, plant profiles, zones, care, fertilizing, pruning, harvest reminders, notes, history, and alerts."],
  [Waves, "Water analytics", "Daily, weekly, monthly, rainwater, refill, estimated savings, and per-zone consumption records."],
  [Zap, "Modular expansion", "Add sensors, zones, cameras, tanks, fertilizer channels, solar power, and environmental sensors over time."],
] as const;

const roadmaps = [
  ["01", "Core prototype", "ESP32 controller, soil sensing, temperature/humidity, tank monitoring, basic irrigation, and web/mobile dashboard."],
  ["02", "Smart water management", "Multi-zone irrigation, flow monitoring, rainwater collection monitoring, water analytics, and low-water protection."],
  ["03", "Weather & microclimate", "Rain, light/UV, wind, and weather-based irrigation decisions."],
  ["04", "Vertical farming", "Vertical-zone data model, per-zone sensors and irrigation, plus expandable sensor nodes."],
  ["05", "AI layer", "Predictive watering, plant recommendations, advisory pest-image analysis, and garden health scoring."],
  ["06", "Automation expansion", "Fertilizer injection, automatic shade, cooling-fan controls, and advanced irrigation routines."],
  ["07", "Growth & commercial product", "Time-lapse, production PCB, weatherproof enclosure, mobile app, cloud, subscriptions, manufacturing, and quality testing."],
] as const;

const investorPoints = [
  ["A usable wedge", "A starter product that saves manual checking and supports core automation without a subscription."],
  ["Expansion economics", "Additional zones, water modules, installation, maintenance, and analytics build from the same operating base."],
  ["Disciplined sequence", "Reliability and outdoor proof come before high-risk AI, chemical dosing, and complex mechanical systems."],
] as const;

const guardrails = [
  ["Critical", "Scope containment", "Freeze the first release around one-to-four-zone irrigation, tank protection, local rules, and manual override. Defer camera AI, fertilizer dosing, shade control, cellular, and multi-property workflows."],
  ["Critical", "Safe physical control", "Bound every watering action with a maximum duration, tank-low cutoff, emergency stop, and normally safe fallback. Test stuck valves, dry pumps, sensor faults, and power loss before pilots."],
  ["High", "Outdoor durability", "Use replaceable capacitive sensors, weatherproof enclosures, protected connectors, drainage, strain relief, and a defined heat, moisture, and ingress test plan."],
  ["High", "Commercial proof", "Choose a single beachhead market, model lifecycle costs before public pricing, and keep basic plant safety hardware-owned instead of forcing a subscription."],
] as const;

const systemLayers = [
  ["01", "Sensor layer", "Capacitive soil moisture, temperature/humidity, light, rain, UV, wind, tank level, and flow signals."],
  ["02", "Edge controller", "ESP32 or equivalent validation, local thresholds, offline-safe decisions, and actuator commands."],
  ["03", "Communication", "Wi-Fi and Bluetooth Low Energy first; LoRa and cellular are optional for larger or remote installations."],
  ["04", "Cloud & backend", "Device and user management, sensor records, alerts, irrigation logs, water analytics, plant profiles, and subscriptions."],
  ["05", "AI & analytics", "Rule engine first; predictive watering, plant recommendations, and human-confirmed visual insight after reliable data exists."],
  ["06", "Mobile & web app", "Dashboard, garden, zones, water, weather, pest, irrigation, fertilizer, growth, analytics, tasks, and settings."],
  ["07", "Actuators", "Pumps, solenoid valves, optional peristaltic dosing, fans, and shade mechanisms with manual override."],
] as const;

const operatingRules = [
  ["Watering", "Evaluate soil thresholds, confirm tank water, consider rainfall and forecast, prioritize configured rainwater, stop at target moisture or critical tank level."],
  ["Weather", "Pause or reduce watering during significant rainfall; raise configured heat alerts; recommend shade/cooling; issue storm-preparation alerts where configured."],
  ["Tank", "Raise low and overflow alerts, pause irrigation at critical levels, and use installed flow measurement to track consumption."],
  ["Vertical zones", "Monitor every level independently, adjust irrigation per zone, surface moisture and light imbalance, and permit expansion nodes."],
] as const;

const commercialItems = [
  ["Starter", "Small balcony gardens", "Soil, temperature/humidity, light, basic irrigation, tank monitoring, and mobile dashboard."],
  ["Pro", "Rooftops & larger balconies", "Starter plus multi-zone monitoring, weather and rainwater monitoring, assisted watering, alerts, and analytics."],
  ["Elite", "Urban farms & vertical gardens", "Pro plus advisory pest insight, vertical zones, fertilizer injection, time-lapse, shade/cooling, advanced analytics, and solar option."],
] as const;

const futureModules = ["Hydroponics", "Aquaponics", "Greenhouse automation", "Autonomous solar station", "LoRa networks", "Disease detection", "Plant recommendations", "Harvest assistance", "Water-quality sensing", "Compost monitoring", "Seedling nursery", "Commercial dashboard", "Multi-property management", "Third-party API"] as const;

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Home() {
  return (
    <div id="top" className="signal-page min-h-screen">
      <PresentationRail />
      <main>
        <section className="relative isolate flex min-h-[760px] items-end overflow-hidden pt-20 lg:min-h-screen">
          <img src="/manus-storage/grinrex-rooftop-garden_6721f8a6.webp" alt="Irrigated rooftop garden in an urban setting" className="hero-image absolute inset-0 -z-20 h-full w-full object-cover" />
          <div className="scrim absolute inset-0 -z-10" />
          <div className="root-grid absolute inset-0 -z-10 opacity-40" />
          <div className="hero-mark" aria-hidden="true"><BrandMark size={132} /><div className="interface mt-3 text-[.62rem] font-extrabold tracking-[.2em] text-[#d9a35c]">LOCAL / MEASURED / SAFE</div></div>
          <div className="mx-auto grid w-full max-w-[1520px] gap-10 px-5 pb-16 pt-20 sm:px-8 lg:grid-cols-[1.2fr_.8fr] lg:px-12 lg:pb-20">
            <div className="max-w-4xl">
              <div className="reveal eyebrow mb-7 flex items-center gap-3 text-[#b8f15a]"><span className="h-2 w-2 rounded-full bg-[#b8f15a] shadow-[0_0_16px_#b8f15a]" /> System brief / 2026</div>
              <h1 className="reveal display max-w-4xl text-5xl leading-[.92] text-[#f4ffe5] sm:text-7xl lg:text-[clamp(4.8rem,7.7vw,8.9rem)]">Every drop has<br /><em className="font-normal text-[#b8f15a]">a destination.</em></h1>
              <p className="reveal-delay mt-7 max-w-xl text-lg leading-8 text-[#d2e4c8] sm:text-xl">Grinrex IoT is the modular, water-intelligent operating system for urban gardens—designed to make plant care measurable, local, and safely automated.</p>
              <div className="reveal-delay mt-9 flex flex-wrap gap-3">
                <button onClick={() => scrollTo("system")} className="cta-button cta-primary">Follow the system <ArrowDown size={15} /></button>
                <button onClick={() => scrollTo("investor")} className="cta-button cta-secondary">Read the investor case <ArrowRight size={15} /></button>
              </div>
            </div>
            <div className="self-end lg:justify-self-end lg:pb-4">
              <div className="glass-panel signal-glow max-w-sm rounded-[1.5rem] p-5">
                <div className="eyebrow text-[#d9a35c]">The operating thesis</div>
                <p className="mt-3 text-[1.02rem] leading-7 text-[#eefadb]">Connect measured garden conditions to safe irrigation, then expand from clear evidence—not feature volume.</p>
                <div className="metric-line mt-5 grid grid-cols-2 gap-3 pt-4 text-sm">
                  <div><div className="interface text-xl font-extrabold text-[#b8f15a]">1–4</div><div className="mt-1 text-xs text-[#b8cdb2]">MVP zones</div></div>
                  <div><div className="interface text-xl font-extrabold text-[#b8f15a]">Local</div><div className="mt-1 text-xs text-[#b8cdb2]">Safety first</div></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="chapter-shell mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="grid gap-16 lg:grid-cols-[.8fr_1.2fr] lg:items-end">
            <SectionHeader index="01" eyebrow="The growing problem" title={<>Urban growing needs an<br /><em className="font-normal text-[#b8f15a]">operating system.</em></>} copy="Balconies, rooftops, terraces, and vertical gardens face the same compounding issue: care is still managed as manual guesswork in conditions that are neither stable nor simple." />
            <div className="grid gap-4 sm:grid-cols-2">
              {["Manual watering is inconsistent.", "Soil conditions are not visible.", "Tanks run out without warning.", "Heat and rainfall change the plan.", "Vertical zones dry unevenly.", "Owners cannot monitor while away."].map((point, index) => (
                <div className="data-card" key={point}><div className="eyebrow text-[#d9a35c]">Signal 0{index + 1}</div><p className="mt-3 text-base leading-6 text-[#e3f1d5]">{point}</p></div>
              ))}
            </div>
          </div>
        </section>

        <section id="system" className="chapter-shell mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="grid gap-12 lg:grid-cols-[1.06fr_.94fr] lg:items-center">
            <div className="image-frame min-h-[420px] rounded-[1.7rem] border border-white/10 shadow-2xl shadow-black/30 sm:min-h-[580px]"><img src="/manus-storage/grinrex-vertical-garden_4e4b00b5.jpg" alt="Modular vertical garden with integrated irrigation" /><div className="absolute bottom-5 left-5 right-5 glass-panel rounded-2xl p-4"><div className="eyebrow text-[#b8f15a]">Designed to expand</div><p className="mt-1 text-sm leading-6 text-[#ebf9db]">Additional sensors and valves add capacity without changing the garden’s core operating logic.</p></div></div>
            <div>
              <SectionHeader index="02" eyebrow="The Grinrex system" title={<>Measure the garden.<br />Decide with <em className="font-normal text-[#d9a35c]">context.</em></>} copy="The system is organized as a reliable physical loop. Sensors collect the signal; the edge controller validates it; local rules protect the garden; the application turns actions and conditions into a useful record." />
              <div className="mt-9 space-y-3">
                {[
                  ["01", "Sense", "Soil, climate, light, rainfall, tank level, and flow."],
                  ["02", "Decide", "Local thresholds first; analytics and recommendations later."],
                  ["03", "Act", "Pumps, valves, fans, and optional garden equipment."],
                  ["04", "Learn", "A readable history of water use, conditions, and outcomes."],
                ].map(([number, title, text]) => <div className="flex gap-4 border-b border-white/10 pb-3" key={number}><span className="interface pt-0.5 text-xs font-extrabold text-[#b8f15a]">{number}</span><div><span className="font-semibold text-[#f1fadc]">{title}</span><span className="ml-2 text-sm text-[#a9c1a2]">{text}</span></div></div>)}
              </div>
            </div>
          </div>
        </section>

        <section id="capabilities" className="chapter-shell root-grid mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <SectionHeader index="03" eyebrow="Complete capability atlas" title={<>One garden loop.<br />A <em className="font-normal text-[#b8f15a]">complete</em> system.</>} copy="Every source module is preserved here in operating order: sensing and water control establish the base; observation, intelligence, and advanced automation expand only when the garden evidence supports them." />
          <div className="mt-12 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {featureModules.map(([Icon, title, text], index) => <article className="glass-panel group rounded-[1.4rem] p-6 transition-transform duration-300 hover:-translate-y-1" key={title}><div className="flex items-start justify-between"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#b8f15a] text-[#143021]"><Icon size={21} /></div><span className="interface text-xs font-extrabold text-[#d9a35c]">0{index + 1}</span></div><h3 className="mt-7 text-xl font-bold text-[#effadf]">{title}</h3><p className="mt-3 max-w-sm text-sm leading-6 text-[#afc5a7]">{text}</p></article>)}
          </div>
        </section>

        <section id="platform" className="chapter-shell mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="grid gap-12 lg:grid-cols-[.82fr_1.18fr] lg:items-start">
            <SectionHeader index="04" eyebrow="Platform architecture" title={<>Seven layers.<br />One <em className="font-normal text-[#d9a35c]">safe</em> data loop.</>} copy="The complete system architecture keeps sensing, local control, communication, records, intelligence, application visibility, and actuation distinct—so critical garden care can stay local and controllable." />
            <div className="grid gap-3 md:grid-cols-2">
              {systemLayers.map(([number, title, text]) => <article className="glass-panel rounded-2xl p-5" key={title}><div className="interface text-xs font-extrabold text-[#d9a35c]">{number}</div><h3 className="mt-4 text-lg font-bold text-[#effadf]">{title}</h3><p className="mt-2 text-sm leading-6 text-[#afc5a7]">{text}</p></article>)}
            </div>
          </div>
          <div className="mt-12 grid gap-4 lg:grid-cols-[1fr_.9fr]">
            <article className="rounded-[1.4rem] border border-[#b8f15a]/20 bg-[#183929] p-6 sm:p-8"><div className="eyebrow text-[#b8f15a]">Hardware & field kit</div><p className="mt-4 max-w-3xl text-lg leading-8 text-[#e4f2d9]">ESP32 control, capacitive soil sensor, BME280, BH1750, rain sensor, UV, anemometer, waterproof ultrasonic level sensor, flow meter, optional ESP32-CAM or Raspberry Pi camera, DC pump, solenoid valves, optional peristaltic pump, fan, servo, DC power, battery backup, optional solar, weatherproof enclosure, waterproof connectors, tubing, drippers, brackets, cable protection, and sensor holders.</p></article>
            <article className="rounded-[1.4rem] border border-[#d9a35c]/25 bg-[#332b1c] p-6 sm:p-8"><div className="eyebrow text-[#d9a35c]">Data and physical rules</div><div className="mt-5 space-y-4">{operatingRules.map(([title, text]) => <div key={title}><h3 className="font-bold text-[#f7e7c6]">{title}</h3><p className="mt-1 text-sm leading-6 text-[#d6c8aa]">{text}</p></div>)}</div></article>
          </div>
        </section>

        <section id="roadmap" className="chapter-shell mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="grid gap-12 lg:grid-cols-[.88fr_1.12fr]">
            <SectionHeader index="05" eyebrow="Execution sequence" title={<>Prove reliability.<br />Then add <em className="font-normal text-[#d9a35c]">intelligence.</em></>} copy="The complete seven-phase source roadmap keeps advanced automation behind the evidence that matters: safe outdoor operation, reliable data, and a system that users choose to keep running." />
            <div className="relative space-y-4">
              <div className="absolute bottom-8 left-[22px] top-8 w-px bg-gradient-to-b from-[#b8f15a] via-[#d9a35c] to-transparent" />
              {roadmaps.map(([number, title, text]) => <article className="relative ml-0 grid grid-cols-[46px_1fr] gap-5" key={number}><div className="interface z-10 flex h-11 w-11 items-center justify-center rounded-full border border-[#b8f15a]/70 bg-[#143021] text-xs font-extrabold text-[#b8f15a]">{number}</div><div className="glass-panel rounded-2xl p-5"><h3 className="text-xl font-bold text-[#f0fbdc]">{title}</h3><p className="mt-2 text-sm leading-6 text-[#aec4a6]">{text}</p></div></article>)}
            </div>
          </div>
        </section>

        <section className="relative overflow-hidden bg-[#0d1e15] py-24 lg:py-32">
          <div className="absolute inset-0 opacity-55"><img src="/manus-storage/grinrex-irrigation_34fc2f30.jpg" alt="Garden irrigation system" className="h-full w-full object-cover object-center" /></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d1e15] via-[#0d1e15]/88 to-[#0d1e15]/40" />
          <div className="relative chapter-shell mx-auto max-w-[1520px] px-5 sm:px-8 lg:px-12"><div className="trail" aria-hidden="true" /><div className="max-w-4xl"><div className="eyebrow flex items-center gap-2 text-[#b8f15a]"><ShieldCheck size={16} /> Non-negotiable principle</div><blockquote className="display mt-7 text-4xl leading-[1.02] text-[#f1fcdf] sm:text-6xl">“Critical systems must remain <em className="font-normal text-[#b8f15a]">locally safe</em> before they become remotely clever.”</blockquote><p className="mt-7 max-w-2xl text-lg leading-8 text-[#c3d4bb]">Grinrex IoT keeps core thresholds and emergency stops close to the garden. The cloud improves visibility; it should not become a prerequisite for basic plant care.</p></div></div>
        </section>

        <section id="guardrails" className="chapter-shell root-grid mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="grid gap-12 lg:grid-cols-[.82fr_1.18fr] lg:items-start">
            <SectionHeader index="06" eyebrow="Launch guardrails" title={<>A smart garden must be<br /><em className="font-normal text-[#d9a35c]">safe before clever.</em></>} copy="The project’s largest risk is attempting too much before the core physical loop is proven. These controls keep the product focused, testable, and commercially honest." />
            <div className="space-y-3">
              {guardrails.map(([level, title, text], index) => <article className="glass-panel grid gap-4 rounded-2xl p-5 sm:grid-cols-[72px_1fr]" key={title}><div className={`interface flex h-fit items-center gap-2 rounded-full px-3 py-2 text-[.6rem] font-extrabold uppercase tracking-[.1em] ${index < 2 ? "bg-[#66431f] text-[#ffd49c]" : "bg-[#294836] text-[#b8f15a]"}`}><TriangleAlert size={12} />{level}</div><div><h3 className="text-lg font-bold text-[#effadf]">{title}</h3><p className="mt-2 text-sm leading-6 text-[#afc5a7]">{text}</p></div></article>)}
            </div>
          </div>
          <div className="mt-10 rounded-[1.45rem] border border-[#b8f15a]/20 bg-[#163425] p-6 sm:p-8"><div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between"><div><div className="eyebrow flex items-center gap-2 text-[#b8f15a]"><ShieldAlert size={15} /> MVP decision</div><p className="mt-3 max-w-3xl text-lg leading-8 text-[#e2efd8]">Launch a garden water-control kit, not an all-in-one urban-farming platform. Every later module must earn its place through reliable pilot evidence, user value, and a clear service model.</p></div><button onClick={() => scrollTo("documents")} className="cta-button cta-primary shrink-0">Read safeguards <ArrowRight size={15} /></button></div></div>
        </section>

        <section id="commercial" className="chapter-shell root-grid mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <SectionHeader index="07" eyebrow="Commercial system" title={<>From balcony kit<br />to <em className="font-normal text-[#b8f15a]">urban infrastructure.</em></>} copy="The original specification supports a staged offering across households, growers, hospitality, education, offices, nurseries, developers, and community gardens. The key is matching product complexity to a clear installation and support model." />
          <div className="mt-12 grid gap-4 lg:grid-cols-3">{commercialItems.map(([tier, target, text], index) => <article className="glass-panel rounded-[1.5rem] p-6" key={tier}><div className="interface text-xs font-extrabold text-[#d9a35c]">0{index + 1} / {tier}</div><h3 className="mt-7 text-2xl font-bold text-[#effadf]">{target}</h3><p className="mt-3 text-sm leading-6 text-[#afc5a7]">{text}</p></article>)}</div>
          <div className="mt-5 grid gap-4 lg:grid-cols-[.95fr_1.05fr]"><article className="rounded-[1.5rem] bg-[#e3f5be] p-7 text-[#1d3a29]"><div className="eyebrow text-[#547531]">Indicative planning prices / INR</div><div className="mt-6 grid gap-3 sm:grid-cols-3"><div><div className="display text-3xl">₹6,999–7,999</div><p className="mt-1 text-sm">Starter kit</p></div><div><div className="display text-3xl">₹9,999–11,999</div><p className="mt-1 text-sm">Pro kit</p></div><div><div className="display text-3xl">₹12,999–16,999</div><p className="mt-1 text-sm">Elite kit</p></div></div><p className="mt-6 text-sm leading-6 text-[#4a604c]">Planning estimates only. Validate against components, manufacturing, taxes, logistics, warranty, installation, and support costs before public pricing. Proposed software tiers: free, Pro ₹149/month or ₹999/year, and Elite ₹249/month or ₹1,699/year.</p></article><article className="rounded-[1.5rem] border border-white/10 bg-[#173426] p-7"><div className="eyebrow text-[#b8f15a]">Revenue, outlook & measurement</div><p className="mt-4 text-sm leading-7 text-[#c4d7ba]">Hardware kits, premium app, sensor and vertical expansions, fertilizer, solar and rainwater add-ons, professional installation, maintenance contracts, B2B projects, and white-label partnerships create the commercial base. Product measures include water saved per garden, reduced manual watering, plant condition, sensor reliability, and irrigation accuracy. Business measures include sales, acquisition cost, margin, subscription conversion, retention, add-on revenue, and B2B installations.</p><div className="mt-5 flex flex-wrap gap-2">{futureModules.map((item) => <span key={item} className="interface rounded-full border border-[#b8f15a]/20 px-2.5 py-1 text-[.58rem] font-extrabold uppercase tracking-[.07em] text-[#cbe6af]">{item}</span>)}</div></article></div>
        </section>

        <section id="investor" className="chapter-shell mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="grid gap-12 lg:grid-cols-[.84fr_1.16fr] lg:items-end">
            <SectionHeader index="08" eyebrow="Investor view" title={<>An investment story<br />grounded in <em className="font-normal text-[#b8f15a]">execution.</em></>} copy="The core bet is not a list of sensors. It is a disciplined system that turns practical garden control into an installed base for modules, service, analytics, and commercial installations." />
            <div className="grid gap-4 md:grid-cols-3">
              {investorPoints.map(([title, text], index) => <article className="rounded-[1.35rem] border border-[#b8f15a]/20 bg-[#173426] p-5" key={title}><span className="interface text-xs font-extrabold text-[#d9a35c]">0{index + 1}</span><h3 className="mt-8 text-lg font-bold text-[#effadf]">{title}</h3><p className="mt-3 text-sm leading-6 text-[#afc6a8]">{text}</p></article>)}
            </div>
          </div>
          <div className="mt-16 grid overflow-hidden rounded-[1.7rem] border border-white/10 lg:grid-cols-[1.1fr_.9fr]">
            <div className="bg-[#dff4ba] p-7 sm:p-10"><div className="eyebrow text-[#56752e]">Packaging concept</div><h3 className="display mt-4 text-4xl leading-none text-[#1a3928]">Hardware first.<br />Value compounds through expansion.</h3><p className="mt-6 max-w-xl leading-7 text-[#48604c]">Starter solves a small balcony use case. Pro extends into multi-zone water intelligence. Elite becomes an installation-led offer for vertical gardens, small farms, schools, restaurants, offices, and property developments.</p><div className="mt-7 flex flex-wrap gap-2">{["Hardware kits", "Expansion zones", "Installations", "Maintenance", "Water analytics", "Decision support"].map((tag) => <span key={tag} className="interface rounded-full border border-[#7ba64b]/40 px-3 py-1.5 text-[.66rem] font-extrabold uppercase tracking-[.08em] text-[#3a5b32]">{tag}</span>)}</div></div>
            <div className="bg-[#173426] p-7 sm:p-10"><div className="eyebrow text-[#b8f15a]">Evidence to earn next</div><div className="mt-6 space-y-4">{["Installation completion and early activation", "Sensor stability and successful irrigation events", "30-day automation retention", "Expansion-module and service attachment", "Measurable reduction in avoidable watering"].map((item) => <div className="flex gap-3 text-sm leading-6 text-[#d7e9cc]" key={item}><Check className="mt-1 shrink-0 text-[#b8f15a]" size={15} />{item}</div>)}</div></div>
          </div>
        </section>

        <section id="documents" className="chapter-shell mx-auto max-w-[1520px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="trail" aria-hidden="true" />
          <div className="mb-12 flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between"><SectionHeader index="09" eyebrow="Document library" title={<>The complete narrative,<br /><em className="font-normal text-[#d9a35c]">in sequence.</em></>} copy="Read the operating brief, technical dossier, investor story, roadmap, risk safeguards, and the full source specification inside the presentation—or download each document for offline review." /><div className="max-w-sm rounded-2xl border border-[#d9a35c]/30 bg-[#3e3420]/45 p-5"><div className="eyebrow text-[#d9a35c]">Reading order</div><p className="mt-2 text-sm leading-6 text-[#e1d8c1]">Start with the operating brief, inspect the technical dossier, commercial case, and delivery roadmap, then use the safeguards and complete source specification as the traceable reference record.</p></div></div>
          <DocumentLibrary />
        </section>

        <footer className="border-t border-white/10 bg-[#0d1e15] px-5 py-14 sm:px-8 lg:px-12">
          <div className="mx-auto flex max-w-[1520px] flex-col gap-8 sm:flex-row sm:items-end sm:justify-between"><div><div className="flex items-center gap-3"><BrandMark size={38} /><span className="interface text-base font-extrabold tracking-[.12em] text-[#efffd3]">GRINREX<span className="text-[#b8f15a]">/</span>IOT</span></div><p className="mt-4 max-w-xl text-sm leading-6 text-[#a8c1a0]">A modular, water-intelligent operating system for urban gardens. Built to move from real garden signals to measurable outcomes.</p></div><button className="cta-button cta-primary" onClick={() => scrollTo("top")}><Zap size={15} /> Return to thesis</button></div>
        </footer>
      </main>
    </div>
  );
}
