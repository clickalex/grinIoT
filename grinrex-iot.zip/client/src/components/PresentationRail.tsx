// Signal Garden navigation — a compact chapter rail that makes the long-form presentation easy to traverse.
import { useEffect, useState } from "react";
import { BrandMark } from "./BrandMark";

const chapters = [
  ["01", "Thesis", "top"],
  ["02", "System", "system"],
  ["03", "Capabilities", "capabilities"],
  ["04", "Platform", "platform"],
  ["05", "Roadmap", "roadmap"],
  ["06", "Guardrails", "guardrails"],
  ["07", "Commercial", "commercial"],
  ["08", "Investor", "investor"],
  ["09", "Documents", "documents"],
] as const;

export function PresentationRail() {
  const [active, setActive] = useState("top");

  useEffect(() => {
    const updateActive = () => {
      const current = chapters
        .map(([, , id]) => document.getElementById(id))
        .filter((element): element is HTMLElement => Boolean(element))
        .reduce((closest, element) => {
          const distance = Math.abs(element.getBoundingClientRect().top - 160);
          return distance < closest.distance ? { id: element.id, distance } : closest;
        }, { id: "top", distance: Number.POSITIVE_INFINITY });
      setActive(current.id);
    };
    window.addEventListener("scroll", updateActive, { passive: true });
    updateActive();
    return () => window.removeEventListener("scroll", updateActive);
  }, []);

  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#102219]/86 backdrop-blur-xl">
        <div className="mx-auto flex h-[4.75rem] max-w-[1520px] items-center justify-between px-4 sm:px-6 lg:px-10">
          <button className="flex items-center gap-2.5 text-left" onClick={() => scrollTo("top")} aria-label="Return to top">
            <BrandMark size={32} />
            <span className="interface text-sm font-extrabold tracking-[.12em] text-[#efffd3]">GRINREX<span className="text-[#b8f15a]">/</span>IOT</span>
          </button>
          <nav className="hidden items-center gap-3 xl:flex" aria-label="Presentation chapters">
            {chapters.map(([number, label, id]) => (
              <button key={id} onClick={() => scrollTo(id)} className={`interface text-[.58rem] font-bold uppercase tracking-[.08em] transition-colors ${active === id ? "text-[#b8f15a]" : "nav-link"}`}>
                <span className="mr-1.5 text-[#d9a35c]">{number}</span>{label}
              </button>
            ))}
          </nav>
          <button className="cta-button cta-primary hidden sm:inline-flex" onClick={() => scrollTo("documents")}>Inspect brief</button>
        </div>
      </header>
      <aside className="signal-instrument" aria-label="Signal trail chapters">
        <div className="instrument-cap interface">LIVE ROUTE</div>
        <div className="instrument-route">
          {chapters.map(([number, label, id], index) => (
            <button key={id} onClick={() => scrollTo(id)} data-active={active === id} className="instrument-node" aria-current={active === id ? "step" : undefined}>
              <span className="instrument-tick" />
              <span className="instrument-number">{number}</span>
              <span className="instrument-label">{label}</span>
              {index === chapters.length - 1 ? <span className="instrument-end">END</span> : null}
            </button>
          ))}
        </div>
      </aside>
    </>
  );
}
